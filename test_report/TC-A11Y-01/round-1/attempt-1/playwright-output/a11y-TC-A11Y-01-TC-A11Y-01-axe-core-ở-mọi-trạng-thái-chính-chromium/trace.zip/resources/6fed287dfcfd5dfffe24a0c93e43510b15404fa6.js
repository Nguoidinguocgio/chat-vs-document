import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/dev/UiShowcase.vue");import { defineComponent as _defineComponent } from "/node_modules/.vite/deps/vue.js?v=87e75e38";
import { ref } from "/node_modules/.vite/deps/vue.js?v=87e75e38";
import {
  Alert,
  Badge,
  Button,
  Dialog,
  EmptyState,
  IconButton,
  Input,
  Menu,
  Popover,
  ProgressBar,
  Skeleton,
  Spinner,
  Textarea,
  Tooltip,
  toast
} from "/src/shared/ui/index.ts";
const _sfc_main = /* @__PURE__ */ _defineComponent({
  __name: "UiShowcase",
  setup(__props, { expose: __expose }) {
    __expose();
    const dialogOpen = ref(false);
    const destructiveOpen = ref(false);
    const name = ref("");
    const note = ref("");
    const menuItems = [
      { key: "profile", label: "Tài khoản" },
      { key: "logout", label: "Đăng xuất" }
    ];
    const __returned__ = { dialogOpen, destructiveOpen, name, note, menuItems, get Alert() {
      return Alert;
    }, get Badge() {
      return Badge;
    }, get Button() {
      return Button;
    }, get Dialog() {
      return Dialog;
    }, get EmptyState() {
      return EmptyState;
    }, get IconButton() {
      return IconButton;
    }, get Input() {
      return Input;
    }, get Menu() {
      return Menu;
    }, get Popover() {
      return Popover;
    }, get ProgressBar() {
      return ProgressBar;
    }, get Skeleton() {
      return Skeleton;
    }, get Spinner() {
      return Spinner;
    }, get Textarea() {
      return Textarea;
    }, get Tooltip() {
      return Tooltip;
    }, get toast() {
      return toast;
    } };
    Object.defineProperty(__returned__, "__isScriptSetup", { enumerable: false, value: true });
    return __returned__;
  }
});
import { createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=87e75e38";
const _hoisted_1 = { class: "mx-auto flex max-w-4xl flex-col gap-8 p-8" };
const _hoisted_2 = {
  "aria-labelledby": "s-btn",
  class: "flex flex-col gap-3"
};
const _hoisted_3 = { class: "flex flex-wrap items-center gap-2" };
const _hoisted_4 = { class: "flex items-center gap-2" };
const _hoisted_5 = {
  "aria-labelledby": "s-form",
  class: "flex max-w-md flex-col gap-3"
};
const _hoisted_6 = {
  "aria-labelledby": "s-badge",
  class: "flex flex-col gap-3"
};
const _hoisted_7 = { class: "flex flex-wrap gap-2" };
const _hoisted_8 = {
  "aria-labelledby": "s-alert",
  class: "flex flex-col gap-3"
};
const _hoisted_9 = {
  "aria-labelledby": "s-prog",
  class: "flex max-w-md flex-col gap-3"
};
const _hoisted_10 = {
  "aria-labelledby": "s-empty",
  class: "flex flex-col gap-3"
};
const _hoisted_11 = {
  "aria-labelledby": "s-ovl",
  class: "flex flex-col gap-3"
};
const _hoisted_12 = { class: "flex flex-wrap gap-2" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return _openBlock(), _createElementBlock("main", _hoisted_1, [
    _cache[42] || (_cache[42] = _createElementVNode(
      "h1",
      { class: "text-xl font-semibold" },
      "Thư viện UI (/dev/ui)",
      -1
      /* CACHED */
    )),
    _createElementVNode("section", _hoisted_2, [
      _cache[18] || (_cache[18] = _createElementVNode(
        "h2",
        {
          id: "s-btn",
          class: "text-lg font-semibold"
        },
        "Button",
        -1
        /* CACHED */
      )),
      _createElementVNode("div", _hoisted_3, [
        _createVNode($setup["Button"], null, {
          default: _withCtx(() => [..._cache[9] || (_cache[9] = [
            _createTextVNode(
              "Tải lên",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], { variant: "secondary" }, {
          default: _withCtx(() => [..._cache[10] || (_cache[10] = [
            _createTextVNode(
              "Hủy",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], { variant: "danger" }, {
          default: _withCtx(() => [..._cache[11] || (_cache[11] = [
            _createTextVNode(
              "Xóa",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], { variant: "ghost" }, {
          default: _withCtx(() => [..._cache[12] || (_cache[12] = [
            _createTextVNode(
              "Thử lại",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], { size: "sm" }, {
          default: _withCtx(() => [..._cache[13] || (_cache[13] = [
            _createTextVNode(
              "Nhỏ",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], { loading: "" }, {
          default: _withCtx(() => [..._cache[14] || (_cache[14] = [
            _createTextVNode(
              "Đang xử lý",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], { disabled: "" }, {
          default: _withCtx(() => [..._cache[15] || (_cache[15] = [
            _createTextVNode(
              "Vô hiệu",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        })
      ]),
      _createElementVNode("div", _hoisted_4, [
        _createVNode($setup["Tooltip"], { text: "Đóng" }, {
          default: _withCtx(() => [
            _createVNode($setup["IconButton"], { label: "Đóng" }, {
              default: _withCtx(() => [..._cache[16] || (_cache[16] = [
                _createTextVNode(
                  "✕",
                  -1
                  /* CACHED */
                )
              ])]),
              _: 1
              /* STABLE */
            })
          ]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["IconButton"], {
          label: "Vô hiệu",
          disabled: ""
        }, {
          default: _withCtx(() => [..._cache[17] || (_cache[17] = [
            _createTextVNode(
              "✕",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        })
      ])
    ]),
    _createElementVNode("section", _hoisted_5, [
      _cache[19] || (_cache[19] = _createElementVNode(
        "h2",
        {
          id: "s-form",
          class: "text-lg font-semibold"
        },
        "Input / Textarea",
        -1
        /* CACHED */
      )),
      _createVNode($setup["Input"], {
        modelValue: $setup.name,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $setup.name = $event),
        label: "Tên tài liệu",
        placeholder: "Điều khoản thanh toán"
      }, null, 8, ["modelValue"]),
      _createVNode($setup["Input"], {
        "model-value": "",
        label: "Email",
        error: "Email không hợp lệ"
      }),
      _createVNode($setup["Textarea"], {
        modelValue: $setup.note,
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $setup.note = $event),
        label: "Ghi chú"
      }, null, 8, ["modelValue"]),
      _createVNode($setup["Textarea"], {
        "model-value": "",
        label: "Câu hỏi",
        error: "Câu hỏi quá dài"
      }),
      _createVNode($setup["Input"], {
        "model-value": "Không sửa được",
        label: "Vô hiệu",
        disabled: ""
      })
    ]),
    _createElementVNode("section", _hoisted_6, [
      _cache[25] || (_cache[25] = _createElementVNode(
        "h2",
        {
          id: "s-badge",
          class: "text-lg font-semibold"
        },
        "Badge",
        -1
        /* CACHED */
      )),
      _createElementVNode("div", _hoisted_7, [
        _createVNode($setup["Badge"], null, {
          default: _withCtx(() => [..._cache[20] || (_cache[20] = [
            _createTextVNode(
              "Trung tính",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Badge"], { tone: "success" }, {
          default: _withCtx(() => [..._cache[21] || (_cache[21] = [
            _createTextVNode(
              "Sẵn sàng",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Badge"], { tone: "warning" }, {
          default: _withCtx(() => [..._cache[22] || (_cache[22] = [
            _createTextVNode(
              "Đang xử lý",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Badge"], { tone: "danger" }, {
          default: _withCtx(() => [..._cache[23] || (_cache[23] = [
            _createTextVNode(
              "Lỗi",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Badge"], { tone: "info" }, {
          default: _withCtx(() => [..._cache[24] || (_cache[24] = [
            _createTextVNode(
              "Mới",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        })
      ])
    ]),
    _createElementVNode("section", _hoisted_8, [
      _cache[30] || (_cache[30] = _createElementVNode(
        "h2",
        {
          id: "s-alert",
          class: "text-lg font-semibold"
        },
        "Alert",
        -1
        /* CACHED */
      )),
      _createVNode($setup["Alert"], null, {
        default: _withCtx(() => [..._cache[26] || (_cache[26] = [
          _createTextVNode(
            "Thông tin chung.",
            -1
            /* CACHED */
          )
        ])]),
        _: 1
        /* STABLE */
      }),
      _createVNode($setup["Alert"], { tone: "warning" }, {
        default: _withCtx(() => [..._cache[27] || (_cache[27] = [
          _createTextVNode(
            "Có 3 trang không đọc được.",
            -1
            /* CACHED */
          )
        ])]),
        _: 1
        /* STABLE */
      }),
      _createVNode($setup["Alert"], { tone: "error" }, {
        action: _withCtx(() => [
          _createVNode($setup["Button"], {
            size: "sm",
            variant: "secondary"
          }, {
            default: _withCtx(() => [..._cache[28] || (_cache[28] = [
              _createTextVNode(
                "Thử lại",
                -1
                /* CACHED */
              )
            ])]),
            _: 1
            /* STABLE */
          })
        ]),
        default: _withCtx(() => [
          _cache[29] || (_cache[29] = _createTextVNode(
            " Không thể xử lý tài liệu. ",
            -1
            /* CACHED */
          ))
        ]),
        _: 1
        /* STABLE */
      })
    ]),
    _createElementVNode("section", _hoisted_9, [
      _cache[31] || (_cache[31] = _createElementVNode(
        "h2",
        {
          id: "s-prog",
          class: "text-lg font-semibold"
        },
        "Spinner / Skeleton / ProgressBar",
        -1
        /* CACHED */
      )),
      _createVNode($setup["Spinner"], { label: "Đang tải" }),
      _createVNode($setup["Skeleton"], { width: "60%" }),
      _createVNode($setup["ProgressBar"], {
        value: 0,
        label: "Chờ tải lên"
      }),
      _createVNode($setup["ProgressBar"], {
        value: 65,
        label: "Tiến trình tải lên"
      }),
      _createVNode($setup["ProgressBar"], {
        value: 100,
        label: "Đã tải lên"
      })
    ]),
    _createElementVNode("section", _hoisted_10, [
      _cache[33] || (_cache[33] = _createElementVNode(
        "h2",
        {
          id: "s-empty",
          class: "text-lg font-semibold"
        },
        "EmptyState",
        -1
        /* CACHED */
      )),
      _createVNode($setup["EmptyState"], {
        title: "Chưa có tài liệu",
        description: "Tải lên tệp PDF đầu tiên để bắt đầu đặt câu hỏi."
      }, {
        default: _withCtx(() => [
          _createVNode($setup["Button"], null, {
            default: _withCtx(() => [..._cache[32] || (_cache[32] = [
              _createTextVNode(
                "Tải lên",
                -1
                /* CACHED */
              )
            ])]),
            _: 1
            /* STABLE */
          })
        ]),
        _: 1
        /* STABLE */
      })
    ]),
    _createElementVNode("section", _hoisted_11, [
      _cache[41] || (_cache[41] = _createElementVNode(
        "h2",
        {
          id: "s-ovl",
          class: "text-lg font-semibold"
        },
        "Dialog / Menu / Popover / Toast",
        -1
        /* CACHED */
      )),
      _createElementVNode("div", _hoisted_12, [
        _createVNode($setup["Button"], {
          variant: "secondary",
          onClick: _cache[2] || (_cache[2] = ($event) => $setup.dialogOpen = true)
        }, {
          default: _withCtx(() => [..._cache[34] || (_cache[34] = [
            _createTextVNode(
              "Mở hộp thoại",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], {
          variant: "danger",
          onClick: _cache[3] || (_cache[3] = ($event) => $setup.destructiveOpen = true)
        }, {
          default: _withCtx(() => [..._cache[35] || (_cache[35] = [
            _createTextVNode(
              "Xóa tài liệu…",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Menu"], {
          items: $setup.menuItems,
          onSelect: _cache[4] || (_cache[4] = (k) => $setup.toast.show(`Chọn: ${k}`))
        }, {
          trigger: _withCtx(() => [
            _createVNode($setup["Button"], { variant: "secondary" }, {
              default: _withCtx(() => [..._cache[36] || (_cache[36] = [
                _createTextVNode(
                  "Menu",
                  -1
                  /* CACHED */
                )
              ])]),
              _: 1
              /* STABLE */
            })
          ]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Popover"], null, {
          trigger: _withCtx(() => [
            _createVNode($setup["Button"], { variant: "secondary" }, {
              default: _withCtx(() => [..._cache[37] || (_cache[37] = [
                _createTextVNode(
                  "Popover",
                  -1
                  /* CACHED */
                )
              ])]),
              _: 1
              /* STABLE */
            })
          ]),
          default: _withCtx(() => [
            _cache[38] || (_cache[38] = _createElementVNode(
              "p",
              null,
              "Trang 4 · Điều khoản thanh toán",
              -1
              /* CACHED */
            ))
          ]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], {
          variant: "ghost",
          onClick: _cache[5] || (_cache[5] = ($event) => $setup.toast.show("Đã lưu thay đổi"))
        }, {
          default: _withCtx(() => [..._cache[39] || (_cache[39] = [
            _createTextVNode(
              "Toast thông tin",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        }),
        _createVNode($setup["Button"], {
          variant: "ghost",
          onClick: _cache[6] || (_cache[6] = ($event) => $setup.toast.error("Tải lên thất bại"))
        }, {
          default: _withCtx(() => [..._cache[40] || (_cache[40] = [
            _createTextVNode(
              "Toast lỗi",
              -1
              /* CACHED */
            )
          ])]),
          _: 1
          /* STABLE */
        })
      ]),
      _createVNode($setup["Dialog"], {
        open: $setup.dialogOpen,
        "onUpdate:open": _cache[7] || (_cache[7] = ($event) => $setup.dialogOpen = $event),
        title: "Xác nhận",
        description: "Bạn có muốn tiếp tục?",
        "confirm-label": "Tiếp tục",
        "cancel-label": "Hủy"
      }, null, 8, ["open"]),
      _createVNode($setup["Dialog"], {
        open: $setup.destructiveOpen,
        "onUpdate:open": _cache[8] || (_cache[8] = ($event) => $setup.destructiveOpen = $event),
        destructive: "",
        title: "Xóa tài liệu",
        description: "Hành động này không thể hoàn tác.",
        "confirm-label": "Xóa",
        "cancel-label": "Hủy"
      }, null, 8, ["open"])
    ])
  ]);
}
_sfc_main.__hmrId = "7227f0d8";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
  if (!mod) return;
  const { default: updated, _rerender_only } = mod;
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
  }
});
import _export_sfc from "/@id/__x00__plugin-vue:export-helper";
export default /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "D:/Learning/AI SDLC/sdlc_project/chat-vs-document/web/src/app/dev/UiShowcase.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVMsV0FBVztBQUNwQjtBQUFBLEVBQ0U7QUFBQSxFQUFPO0FBQUEsRUFBTztBQUFBLEVBQVE7QUFBQSxFQUFRO0FBQUEsRUFBWTtBQUFBLEVBQVk7QUFBQSxFQUFPO0FBQUEsRUFBTTtBQUFBLEVBQVM7QUFBQSxFQUFhO0FBQUEsRUFBVTtBQUFBLEVBQVM7QUFBQSxFQUFVO0FBQUEsRUFBUztBQUFBLE9BQzFIOzs7OztBQUVQLFVBQU0sYUFBYSxJQUFJLEtBQUs7QUFDNUIsVUFBTSxrQkFBa0IsSUFBSSxLQUFLO0FBQ2pDLFVBQU0sT0FBTyxJQUFJLEVBQUU7QUFDbkIsVUFBTSxPQUFPLElBQUksRUFBRTtBQUNuQixVQUFNLFlBQVk7QUFBQSxNQUNoQixFQUFFLEtBQUssV0FBVyxPQUFPLFlBQVk7QUFBQSxNQUNyQyxFQUFFLEtBQUssVUFBVSxPQUFPLFlBQVk7QUFBQSxJQUN0Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFJUSxPQUFNLDRDQUEyQzs7RUFHNUMsbUJBQWdCO0FBQUEsRUFBUSxPQUFNOztxQkFFaEMsT0FBTSxvQ0FBbUM7cUJBU3pDLE9BQU0sMEJBQXlCOztFQU03QixtQkFBZ0I7QUFBQSxFQUFTLE9BQU07OztFQVMvQixtQkFBZ0I7QUFBQSxFQUFVLE9BQU07O3FCQUVsQyxPQUFNLHVCQUFzQjs7RUFNMUIsbUJBQWdCO0FBQUEsRUFBVSxPQUFNOzs7RUFVaEMsbUJBQWdCO0FBQUEsRUFBUyxPQUFNOzs7RUFTL0IsbUJBQWdCO0FBQUEsRUFBVSxPQUFNOzs7RUFPaEMsbUJBQWdCO0FBQUEsRUFBUSxPQUFNOztzQkFFaEMsT0FBTSx1QkFBc0I7O3VCQWpFckMsb0JBaUZPLFFBakZQLFlBaUZPO0FBQUEsZ0NBaEZMO0FBQUEsTUFBNEQ7QUFBQSxRQUF4RCxPQUFNLHdCQUF1QjtBQUFBLE1BQUM7QUFBQSxNQUFxQjtBQUFBO0FBQUE7QUFBQSxJQUV2RCxvQkFlVSxXQWZWLFlBZVU7QUFBQSxrQ0FkUjtBQUFBLFFBQXdEO0FBQUE7QUFBQSxVQUFwRCxJQUFHO0FBQUEsVUFBUSxPQUFNO0FBQUE7UUFBd0I7QUFBQSxRQUFNO0FBQUE7QUFBQTtBQUFBLE1BQ25ELG9CQVFNLE9BUk4sWUFRTTtBQUFBLFFBUEosYUFBd0I7QUFBQSw0QkFBaEIsTUFBTztBQUFBO2NBQVA7QUFBQSxjQUFPO0FBQUE7QUFBQTtBQUFBOzs7O1FBQ2YsYUFBd0Msb0JBQWhDLFNBQVEsWUFBVztBQUFBLDRCQUFDLE1BQUc7QUFBQTtjQUFIO0FBQUEsY0FBRztBQUFBO0FBQUE7QUFBQTs7OztRQUMvQixhQUFxQyxvQkFBN0IsU0FBUSxTQUFRO0FBQUEsNEJBQUMsTUFBRztBQUFBO2NBQUg7QUFBQSxjQUFHO0FBQUE7QUFBQTtBQUFBOzs7O1FBQzVCLGFBQXdDLG9CQUFoQyxTQUFRLFFBQU87QUFBQSw0QkFBQyxNQUFPO0FBQUE7Y0FBUDtBQUFBLGNBQU87QUFBQTtBQUFBO0FBQUE7Ozs7UUFDL0IsYUFBOEIsb0JBQXRCLE1BQUssS0FBSTtBQUFBLDRCQUFDLE1BQUc7QUFBQTtjQUFIO0FBQUEsY0FBRztBQUFBO0FBQUE7QUFBQTs7OztRQUNyQixhQUFtQyxvQkFBM0IsWUFBTztBQUFBLDRCQUFDLE1BQVU7QUFBQTtjQUFWO0FBQUEsY0FBVTtBQUFBO0FBQUE7QUFBQTs7OztRQUMxQixhQUFpQyxvQkFBekIsYUFBUTtBQUFBLDRCQUFDLE1BQU87QUFBQTtjQUFQO0FBQUEsY0FBTztBQUFBO0FBQUE7QUFBQTs7Ozs7TUFFMUIsb0JBR00sT0FITixZQUdNO0FBQUEsUUFGSixhQUFzRSxxQkFBN0QsTUFBSyxPQUFNO0FBQUEsNEJBQUMsTUFBdUM7QUFBQSxZQUF2QyxhQUF1Qyx3QkFBM0IsT0FBTSxPQUFNO0FBQUEsZ0NBQUMsTUFBQztBQUFBO2tCQUFEO0FBQUEsa0JBQUM7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7O1FBQy9DLGFBQW1EO0FBQUEsVUFBdkMsT0FBTTtBQUFBLFVBQVU7QUFBQTs0QkFBUyxNQUFDO0FBQUE7Y0FBRDtBQUFBLGNBQUM7QUFBQTtBQUFBO0FBQUE7Ozs7OztJQUkxQyxvQkFPVSxXQVBWLFlBT1U7QUFBQSxrQ0FOUjtBQUFBLFFBQW1FO0FBQUE7QUFBQSxVQUEvRCxJQUFHO0FBQUEsVUFBUyxPQUFNO0FBQUE7UUFBd0I7QUFBQSxRQUFnQjtBQUFBO0FBQUE7QUFBQSxNQUM5RCxhQUFpRjtBQUFBLG9CQUFqRTtBQUFBLG1GQUFJO0FBQUEsUUFBRSxPQUFNO0FBQUEsUUFBZSxhQUFZO0FBQUE7TUFDdkQsYUFBaUU7QUFBQSxRQUExRCxlQUFZO0FBQUEsUUFBRyxPQUFNO0FBQUEsUUFBUSxPQUFNO0FBQUE7TUFDMUMsYUFBMkM7QUFBQSxvQkFBeEI7QUFBQSxtRkFBSTtBQUFBLFFBQUUsT0FBTTtBQUFBO01BQy9CLGFBQW1FO0FBQUEsUUFBekQsZUFBWTtBQUFBLFFBQUcsT0FBTTtBQUFBLFFBQVUsT0FBTTtBQUFBO01BQy9DLGFBQStEO0FBQUEsUUFBeEQsZUFBWTtBQUFBLFFBQWlCLE9BQU07QUFBQSxRQUFVO0FBQUE7O0lBR3RELG9CQU1VLFdBTlYsWUFNVTtBQUFBLGtDQUxSO0FBQUEsUUFBeUQ7QUFBQTtBQUFBLFVBQXJELElBQUc7QUFBQSxVQUFVLE9BQU07QUFBQTtRQUF3QjtBQUFBLFFBQUs7QUFBQTtBQUFBO0FBQUEsTUFDcEQsb0JBR00sT0FITixZQUdNO0FBQUEsUUFGSixhQUF5QjtBQUFBLDRCQUFsQixNQUFVO0FBQUE7Y0FBVjtBQUFBLGNBQVU7QUFBQTtBQUFBO0FBQUE7Ozs7UUFBUSxhQUFzQyxtQkFBL0IsTUFBSyxVQUFTO0FBQUEsNEJBQUMsTUFBUTtBQUFBO2NBQVI7QUFBQSxjQUFRO0FBQUE7QUFBQTtBQUFBOzs7O1FBQVEsYUFBd0MsbUJBQWpDLE1BQUssVUFBUztBQUFBLDRCQUFDLE1BQVU7QUFBQTtjQUFWO0FBQUEsY0FBVTtBQUFBO0FBQUE7QUFBQTs7OztRQUMvRixhQUFnQyxtQkFBekIsTUFBSyxTQUFRO0FBQUEsNEJBQUMsTUFBRztBQUFBO2NBQUg7QUFBQSxjQUFHO0FBQUE7QUFBQTtBQUFBOzs7O1FBQVEsYUFBOEIsbUJBQXZCLE1BQUssT0FBTTtBQUFBLDRCQUFDLE1BQUc7QUFBQTtjQUFIO0FBQUEsY0FBRztBQUFBO0FBQUE7QUFBQTs7Ozs7O0lBSTFELG9CQVFVLFdBUlYsWUFRVTtBQUFBLGtDQVBSO0FBQUEsUUFBeUQ7QUFBQTtBQUFBLFVBQXJELElBQUc7QUFBQSxVQUFVLE9BQU07QUFBQTtRQUF3QjtBQUFBLFFBQUs7QUFBQTtBQUFBO0FBQUEsTUFDcEQsYUFBK0I7QUFBQSwwQkFBeEIsTUFBZ0I7QUFBQTtZQUFoQjtBQUFBLFlBQWdCO0FBQUE7QUFBQTtBQUFBOzs7O01BQ3ZCLGFBQXdELG1CQUFqRCxNQUFLLFVBQVM7QUFBQSwwQkFBQyxNQUEwQjtBQUFBO1lBQTFCO0FBQUEsWUFBMEI7QUFBQTtBQUFBO0FBQUE7Ozs7TUFDaEQsYUFHUSxtQkFIRCxNQUFLLFFBQU87QUFBQSxRQUVOLFFBQU0sU0FBQyxNQUFzRDtBQUFBLFVBQXRELGFBQXNEO0FBQUEsWUFBOUMsTUFBSztBQUFBLFlBQUssU0FBUTtBQUFBOzhCQUFZLE1BQU87QUFBQTtnQkFBUDtBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBOzs7OzswQkFGN0MsTUFFbEI7QUFBQTtZQUZrQjtBQUFBLFlBRWxCO0FBQUE7QUFBQTtBQUFBOzs7OztJQUlKLG9CQU9VLFdBUFYsWUFPVTtBQUFBLGtDQU5SO0FBQUEsUUFBbUY7QUFBQTtBQUFBLFVBQS9FLElBQUc7QUFBQSxVQUFTLE9BQU07QUFBQTtRQUF3QjtBQUFBLFFBQWdDO0FBQUE7QUFBQTtBQUFBLE1BQzlFLGFBQTRCLHFCQUFuQixPQUFNLFdBQVU7QUFBQSxNQUN6QixhQUF3QixzQkFBZCxPQUFNLE1BQUs7QUFBQSxNQUNyQixhQUE4QztBQUFBLFFBQWhDLE9BQU87QUFBQSxRQUFHLE9BQU07QUFBQTtNQUM5QixhQUFzRDtBQUFBLFFBQXhDLE9BQU87QUFBQSxRQUFJLE9BQU07QUFBQTtNQUMvQixhQUErQztBQUFBLFFBQWpDLE9BQU87QUFBQSxRQUFLLE9BQU07QUFBQTs7SUFHbEMsb0JBS1UsV0FMVixhQUtVO0FBQUEsa0NBSlI7QUFBQSxRQUE4RDtBQUFBO0FBQUEsVUFBMUQsSUFBRztBQUFBLFVBQVUsT0FBTTtBQUFBO1FBQXdCO0FBQUEsUUFBVTtBQUFBO0FBQUE7QUFBQSxNQUN6RCxhQUVhO0FBQUEsUUFGRCxPQUFNO0FBQUEsUUFBbUIsYUFBWTtBQUFBOzBCQUMvQyxNQUF3QjtBQUFBLFVBQXhCLGFBQXdCO0FBQUEsOEJBQWhCLE1BQU87QUFBQTtnQkFBUDtBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7SUFJbkIsb0JBaUJVLFdBakJWLGFBaUJVO0FBQUEsa0NBaEJSO0FBQUEsUUFBaUY7QUFBQTtBQUFBLFVBQTdFLElBQUc7QUFBQSxVQUFRLE9BQU07QUFBQTtRQUF3QjtBQUFBLFFBQStCO0FBQUE7QUFBQTtBQUFBLE1BQzVFLG9CQVlNLE9BWk4sYUFZTTtBQUFBLFFBWEosYUFBNEU7QUFBQSxVQUFwRSxTQUFRO0FBQUEsVUFBYSxTQUFLLHNDQUFFLG9CQUFVO0FBQUE7NEJBQVMsTUFBWTtBQUFBO2NBQVo7QUFBQSxjQUFZO0FBQUE7QUFBQTtBQUFBOzs7O1FBQ25FLGFBQStFO0FBQUEsVUFBdkUsU0FBUTtBQUFBLFVBQVUsU0FBSyxzQ0FBRSx5QkFBZTtBQUFBOzRCQUFTLE1BQWE7QUFBQTtjQUFiO0FBQUEsY0FBYTtBQUFBO0FBQUE7QUFBQTs7OztRQUN0RSxhQUVPO0FBQUEsVUFGQSxPQUFPO0FBQUEsVUFBWSxVQUFNLDJCQUFHLE1BQU0sYUFBTSxLQUFJLFNBQVUsQ0FBQztBQUFBO1VBQ2pELFNBQU8sU0FBQyxNQUF5QztBQUFBLFlBQXpDLGFBQXlDLG9CQUFqQyxTQUFRLFlBQVc7QUFBQSxnQ0FBQyxNQUFJO0FBQUE7a0JBQUo7QUFBQSxrQkFBSTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7UUFFckQsYUFHVTtBQUFBLFVBRkcsU0FBTyxTQUFDLE1BQTRDO0FBQUEsWUFBNUMsYUFBNEMsb0JBQXBDLFNBQVEsWUFBVztBQUFBLGdDQUFDLE1BQU87QUFBQTtrQkFBUDtBQUFBLGtCQUFPO0FBQUE7QUFBQTtBQUFBOzs7Ozs0QkFDdEQsTUFBc0M7QUFBQSx3Q0FBdEM7QUFBQSxjQUFzQztBQUFBO0FBQUEsY0FBbkM7QUFBQSxjQUErQjtBQUFBO0FBQUE7QUFBQTs7OztRQUVwQyxhQUF1RjtBQUFBLFVBQS9FLFNBQVE7QUFBQSxVQUFTLFNBQUssc0NBQUUsYUFBTSxLQUFJO0FBQUE7NEJBQXFCLE1BQWU7QUFBQTtjQUFmO0FBQUEsY0FBZTtBQUFBO0FBQUE7QUFBQTs7OztRQUM5RSxhQUFtRjtBQUFBLFVBQTNFLFNBQVE7QUFBQSxVQUFTLFNBQUssc0NBQUUsYUFBTSxNQUFLO0FBQUE7NEJBQXNCLE1BQVM7QUFBQTtjQUFUO0FBQUEsY0FBUztBQUFBO0FBQUE7QUFBQTs7Ozs7TUFFNUUsYUFBcUk7QUFBQSxRQUFySCxNQUFNO0FBQUEsbUZBQVU7QUFBQSxRQUFFLE9BQU07QUFBQSxRQUFXLGFBQVk7QUFBQSxRQUF3QixpQkFBYztBQUFBLFFBQVcsZ0JBQWE7QUFBQTtNQUM3SCxhQUFpSztBQUFBLFFBQWpKLE1BQU07QUFBQSx3RkFBZTtBQUFBLFFBQUU7QUFBQSxRQUFZLE9BQU07QUFBQSxRQUFlLGFBQVk7QUFBQSxRQUFvQyxpQkFBYztBQUFBLFFBQU0sZ0JBQWE7QUFBQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVWlTaG93Y2FzZS52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBzZXR1cCBsYW5nPVwidHNcIj5cbmltcG9ydCB7IHJlZiB9IGZyb20gJ3Z1ZSdcbmltcG9ydCB7XG4gIEFsZXJ0LCBCYWRnZSwgQnV0dG9uLCBEaWFsb2csIEVtcHR5U3RhdGUsIEljb25CdXR0b24sIElucHV0LCBNZW51LCBQb3BvdmVyLCBQcm9ncmVzc0JhciwgU2tlbGV0b24sIFNwaW5uZXIsIFRleHRhcmVhLCBUb29sdGlwLCB0b2FzdCxcbn0gZnJvbSAnQC9zaGFyZWQvdWknXG5cbmNvbnN0IGRpYWxvZ09wZW4gPSByZWYoZmFsc2UpXG5jb25zdCBkZXN0cnVjdGl2ZU9wZW4gPSByZWYoZmFsc2UpXG5jb25zdCBuYW1lID0gcmVmKCcnKVxuY29uc3Qgbm90ZSA9IHJlZignJylcbmNvbnN0IG1lbnVJdGVtcyA9IFtcbiAgeyBrZXk6ICdwcm9maWxlJywgbGFiZWw6ICdUw6BpIGtob+G6o24nIH0sXG4gIHsga2V5OiAnbG9nb3V0JywgbGFiZWw6ICfEkMSDbmcgeHXhuqV0JyB9LFxuXVxuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPG1haW4gY2xhc3M9XCJteC1hdXRvIGZsZXggbWF4LXctNHhsIGZsZXgtY29sIGdhcC04IHAtOFwiPlxuICAgIDxoMSBjbGFzcz1cInRleHQteGwgZm9udC1zZW1pYm9sZFwiPlRoxrAgdmnhu4duIFVJICgvZGV2L3VpKTwvaDE+XG5cbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJzLWJ0blwiIGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgPGgyIGlkPVwicy1idG5cIiBjbGFzcz1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPkJ1dHRvbjwvaDI+XG4gICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgIDxCdXR0b24+VOG6o2kgbMOqbjwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5I4buneTwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYW5nZXJcIj5Yw7NhPC9CdXR0b24+XG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCI+VGjhu60gbOG6oWk8L0J1dHRvbj5cbiAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIj5OaOG7jzwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uIGxvYWRpbmc+xJBhbmcgeOG7rSBsw708L0J1dHRvbj5cbiAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD5Ww7QgaGnhu4d1PC9CdXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICA8VG9vbHRpcCB0ZXh0PVwixJDDs25nXCI+PEljb25CdXR0b24gbGFiZWw9XCLEkMOzbmdcIj7inJU8L0ljb25CdXR0b24+PC9Ub29sdGlwPlxuICAgICAgICA8SWNvbkJ1dHRvbiBsYWJlbD1cIlbDtCBoaeG7h3VcIiBkaXNhYmxlZD7inJU8L0ljb25CdXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJzLWZvcm1cIiBjbGFzcz1cImZsZXggbWF4LXctbWQgZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgIDxoMiBpZD1cInMtZm9ybVwiIGNsYXNzPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+SW5wdXQgLyBUZXh0YXJlYTwvaDI+XG4gICAgICA8SW5wdXQgdi1tb2RlbD1cIm5hbWVcIiBsYWJlbD1cIlTDqm4gdMOgaSBsaeG7h3VcIiBwbGFjZWhvbGRlcj1cIsSQaeG7gXUga2hv4bqjbiB0aGFuaCB0b8OhblwiIC8+XG4gICAgICA8SW5wdXQgbW9kZWwtdmFsdWU9XCJcIiBsYWJlbD1cIkVtYWlsXCIgZXJyb3I9XCJFbWFpbCBraMO0bmcgaOG7o3AgbOG7h1wiIC8+XG4gICAgICA8VGV4dGFyZWEgdi1tb2RlbD1cIm5vdGVcIiBsYWJlbD1cIkdoaSBjaMO6XCIgLz5cbiAgICAgIDxUZXh0YXJlYSBtb2RlbC12YWx1ZT1cIlwiIGxhYmVsPVwiQ8OidSBo4buPaVwiIGVycm9yPVwiQ8OidSBo4buPaSBxdcOhIGTDoGlcIiAvPlxuICAgICAgPElucHV0IG1vZGVsLXZhbHVlPVwiS2jDtG5nIHPhu61hIMSRxrDhu6NjXCIgbGFiZWw9XCJWw7QgaGnhu4d1XCIgZGlzYWJsZWQgLz5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJzLWJhZGdlXCIgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICA8aDIgaWQ9XCJzLWJhZGdlXCIgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5CYWRnZTwvaDI+XG4gICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgPEJhZGdlPlRydW5nIHTDrW5oPC9CYWRnZT48QmFkZ2UgdG9uZT1cInN1Y2Nlc3NcIj5T4bq1biBzw6BuZzwvQmFkZ2U+PEJhZGdlIHRvbmU9XCJ3YXJuaW5nXCI+xJBhbmcgeOG7rSBsw708L0JhZGdlPlxuICAgICAgICA8QmFkZ2UgdG9uZT1cImRhbmdlclwiPkzhu5dpPC9CYWRnZT48QmFkZ2UgdG9uZT1cImluZm9cIj5N4bubaTwvQmFkZ2U+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG5cbiAgICA8c2VjdGlvbiBhcmlhLWxhYmVsbGVkYnk9XCJzLWFsZXJ0XCIgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICA8aDIgaWQ9XCJzLWFsZXJ0XCIgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5BbGVydDwvaDI+XG4gICAgICA8QWxlcnQ+VGjDtG5nIHRpbiBjaHVuZy48L0FsZXJ0PlxuICAgICAgPEFsZXJ0IHRvbmU9XCJ3YXJuaW5nXCI+Q8OzIDMgdHJhbmcga2jDtG5nIMSR4buNYyDEkcaw4bujYy48L0FsZXJ0PlxuICAgICAgPEFsZXJ0IHRvbmU9XCJlcnJvclwiPlxuICAgICAgICBLaMO0bmcgdGjhu4MgeOG7rSBsw70gdMOgaSBsaeG7h3UuXG4gICAgICAgIDx0ZW1wbGF0ZSAjYWN0aW9uPjxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiPlRo4butIGzhuqFpPC9CdXR0b24+PC90ZW1wbGF0ZT5cbiAgICAgIDwvQWxlcnQ+XG4gICAgPC9zZWN0aW9uPlxuXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbGxlZGJ5PVwicy1wcm9nXCIgY2xhc3M9XCJmbGV4IG1heC13LW1kIGZsZXgtY29sIGdhcC0zXCI+XG4gICAgICA8aDIgaWQ9XCJzLXByb2dcIiBjbGFzcz1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlNwaW5uZXIgLyBTa2VsZXRvbiAvIFByb2dyZXNzQmFyPC9oMj5cbiAgICAgIDxTcGlubmVyIGxhYmVsPVwixJBhbmcgdOG6o2lcIiAvPlxuICAgICAgPFNrZWxldG9uIHdpZHRoPVwiNjAlXCIgLz5cbiAgICAgIDxQcm9ncmVzc0JhciA6dmFsdWU9XCIwXCIgbGFiZWw9XCJDaOG7nSB04bqjaSBsw6puXCIgLz5cbiAgICAgIDxQcm9ncmVzc0JhciA6dmFsdWU9XCI2NVwiIGxhYmVsPVwiVGnhur9uIHRyw6xuaCB04bqjaSBsw6puXCIgLz5cbiAgICAgIDxQcm9ncmVzc0JhciA6dmFsdWU9XCIxMDBcIiBsYWJlbD1cIsSQw6MgdOG6o2kgbMOqblwiIC8+XG4gICAgPC9zZWN0aW9uPlxuXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbGxlZGJ5PVwicy1lbXB0eVwiIGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgPGgyIGlkPVwicy1lbXB0eVwiIGNsYXNzPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+RW1wdHlTdGF0ZTwvaDI+XG4gICAgICA8RW1wdHlTdGF0ZSB0aXRsZT1cIkNoxrBhIGPDsyB0w6BpIGxp4buHdVwiIGRlc2NyaXB0aW9uPVwiVOG6o2kgbMOqbiB04buHcCBQREYgxJHhuqd1IHRpw6puIMSR4buDIGLhuq90IMSR4bqndSDEkeG6t3QgY8OidSBo4buPaS5cIj5cbiAgICAgICAgPEJ1dHRvbj5U4bqjaSBsw6puPC9CdXR0b24+XG4gICAgICA8L0VtcHR5U3RhdGU+XG4gICAgPC9zZWN0aW9uPlxuXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbGxlZGJ5PVwicy1vdmxcIiBjbGFzcz1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgIDxoMiBpZD1cInMtb3ZsXCIgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5EaWFsb2cgLyBNZW51IC8gUG9wb3ZlciAvIFRvYXN0PC9oMj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBAY2xpY2s9XCJkaWFsb2dPcGVuID0gdHJ1ZVwiPk3hu58gaOG7mXAgdGhv4bqhaTwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJkYW5nZXJcIiBAY2xpY2s9XCJkZXN0cnVjdGl2ZU9wZW4gPSB0cnVlXCI+WMOzYSB0w6BpIGxp4buHdeKApjwvQnV0dG9uPlxuICAgICAgICA8TWVudSA6aXRlbXM9XCJtZW51SXRlbXNcIiBAc2VsZWN0PVwiKGspID0+IHRvYXN0LnNob3coYENo4buNbjogJHtrfWApXCI+XG4gICAgICAgICAgPHRlbXBsYXRlICN0cmlnZ2VyPjxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiPk1lbnU8L0J1dHRvbj48L3RlbXBsYXRlPlxuICAgICAgICA8L01lbnU+XG4gICAgICAgIDxQb3BvdmVyPlxuICAgICAgICAgIDx0ZW1wbGF0ZSAjdHJpZ2dlcj48QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5Qb3BvdmVyPC9CdXR0b24+PC90ZW1wbGF0ZT5cbiAgICAgICAgICA8cD5UcmFuZyA0IMK3IMSQaeG7gXUga2hv4bqjbiB0aGFuaCB0b8OhbjwvcD5cbiAgICAgICAgPC9Qb3BvdmVyPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIEBjbGljaz1cInRvYXN0LnNob3coJ8SQw6MgbMawdSB0aGF5IMSR4buVaScpXCI+VG9hc3QgdGjDtG5nIHRpbjwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIEBjbGljaz1cInRvYXN0LmVycm9yKCdU4bqjaSBsw6puIHRo4bqldCBi4bqhaScpXCI+VG9hc3QgbOG7l2k8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPERpYWxvZyB2LW1vZGVsOm9wZW49XCJkaWFsb2dPcGVuXCIgdGl0bGU9XCJYw6FjIG5o4bqtblwiIGRlc2NyaXB0aW9uPVwiQuG6oW4gY8OzIG114buRbiB0aeG6v3AgdOG7pWM/XCIgY29uZmlybS1sYWJlbD1cIlRp4bq/cCB04bulY1wiIGNhbmNlbC1sYWJlbD1cIkjhu6d5XCIgLz5cbiAgICAgIDxEaWFsb2cgdi1tb2RlbDpvcGVuPVwiZGVzdHJ1Y3RpdmVPcGVuXCIgZGVzdHJ1Y3RpdmUgdGl0bGU9XCJYw7NhIHTDoGkgbGnhu4d1XCIgZGVzY3JpcHRpb249XCJIw6BuaCDEkeG7mW5nIG7DoHkga2jDtG5nIHRo4buDIGhvw6BuIHTDoWMuXCIgY29uZmlybS1sYWJlbD1cIljDs2FcIiBjYW5jZWwtbGFiZWw9XCJI4buneVwiIC8+XG4gICAgPC9zZWN0aW9uPlxuICA8L21haW4+XG48L3RlbXBsYXRlPlxuIl0sImZpbGUiOiJEOi9MZWFybmluZy9BSSBTRExDL3NkbGNfcHJvamVjdC9jaGF0LXZzLWRvY3VtZW50L3dlYi9zcmMvYXBwL2Rldi9VaVNob3djYXNlLnZ1ZSJ9